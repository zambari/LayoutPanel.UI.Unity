﻿// THIS IS A CLONE OF SHOWONLY
// renamed so I could packake it with zTools - i use it a lot

// I am ont an author of this
namespace LayoutPanelDependencies
{
    using UnityEngine;

    public class ReadOnlyAttribute : PropertyAttribute
    {
    }
}