using System;
namespace LayoutPanelDependencies
{ 
    [System.Serializable]

    public class DrawInspectorBg { public int nothing; }
}